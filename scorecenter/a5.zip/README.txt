Andrew Mendelsohn - a5
ScoreCenter

Implementation:
All aspects have been correctly implemented.

Collaboration:
I collaborated with Tyler Lubeck and Alison Tai.

Time Spent:
I spent approximately 10 hours on this assignment.