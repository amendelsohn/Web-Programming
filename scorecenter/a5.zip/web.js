// Express initialization
var express = require("express");
var app = express();
app.use(express.logger());
app.use(express.bodyParser());
app.set('scorecenter', 'nodeapp');

// Mongo initialization
var mongoUri = process.env.MONGOLAB_URI ||
  process.env.MONGOHQ_URL ||
  'mongodb://localhost/scorecenter';
var db = require('mongojs').connect(mongoUri, ['scores']);

// allow cross-domain access
app.post('/submit.json', function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    next();
});
app.get('/highscores.json', function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'X-Requested-With');
    next();
});

function score (game_title, username, score) {
	this.game_title = game_title;
	this.username = username;
	this.score = score;
	this.created_at = new Date().toString();
}

app.get('/', function (request, response) {
	var resp = "<h1>High Scores:</h1>";
	resp += "<table>";
	db.scores.find(function (er, scores) {
		if (er || !scores.length) {
			console.log("Entries not found");
		} else {
			scores.forEach(function(score) {
				resp += "<tr>";
				resp += "<td>" + score.game_title 	+ "</td>";
				resp += "<td>" + score.username 	+ "</td>";
				resp += "<td>" + score.score 		+ "</td>";
				resp += "</tr>";
			});
		}
		resp += "</table>";
		response.set('Content-Type', 'text/html');
		response.send(resp);
	});
});

app.get('/highscores.json', function (request, response) {
	db.scores.find({game_title: request.query.game_title}, {limit:10}).sort({score:-1}, function (er, results) {
			if(!er) {
				response.set('Content-Type', 'text/json');
				response.send(results);
			}
			else
				console.log("No results for " + game_title + ".");
	});
});

app.post('/submit.json', function (request, response) {
	query = request.body;
	entry = new score(query.game_title, query.username, Number(query.score));
	db.scores.save(entry, {safe: true}, function (er,rs) {
		if (er) console.log("saving error");
	});
	response.set('Content-Type', 'text/json');
	response.send(entry);
});

app.get('/usersearch', function (request, response) {
	response.set('Content-Type', 'text/html');
	response.send('<form id="input" name="search" action="usersearch" method="post"> Username: <input type="text" name="username"> <input type="submit" id="submit" value="Submit"> </form>');
});

app.post('/usersearch', function (request, response) {
	var resp = "<h1>High Scores:</h1>";
	resp += "<table>";
	db.scores.find({username: request.body.username}).sort({game_title:1}, function (er, scores) {
		if (er || !scores.length) {
			console.log("Entries not found");
		} else {
			scores.forEach(function(score) {
				resp += "<tr>";
				resp += "<td>" + score.game_title 	+ "</td>";
				resp += "<td>" + score.username 	+ "</td>";
				resp += "<td>" + score.score 		+ "</td>";
				resp += "</tr>";
			});
		}
		resp += "</table>";
		response.set('Content-Type', 'text/html');
		response.send(resp);
	});
});


// Oh joy! http://stackoverflow.com/questions/15693192/heroku-node-js-error-web
//-process-failed-to-bind-to-port-within-60-seconds-of
app.listen(process.env.PORT || 3000);