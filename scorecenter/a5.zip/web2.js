var express = require('express');
var app = express.createServer(express.logger());

var mongo = require('mongodb');
var mongoUri = process.env.MONGOLAB_URI || 
  process.env.MONGOHQ_URL || 
  'mongodb://localhost/mydb'; 

var db = new Db('test', new Server(mongoUri, 27017, {}), {w: 1}),

app.get('/highscores.json', function(request, response) {
  	response.send("");
  	});

app.post('/submit.json', function(request, response) {
	// body...
  	});

//listener
  var port = process.env.PORT || 5000;
  app.listen(port, function() {
    console.log("Listening on " + port);
    });



function dbInsert (key, val) {
	var entry[key] = val;
	mongo.Db.connect(mongoUri, function (err, db) {
  		db.collection('mydocs', function(er, collection) {
    	collection.insert(entry, {safe: true}, function(er,rs) {
    });
  });
});
}


